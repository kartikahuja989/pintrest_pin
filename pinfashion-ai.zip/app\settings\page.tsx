import Link from "next/link";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
export default function SettingsPage() { return <AppShell><div className="mb-6"><h1 className="text-3xl font-black">Settings</h1><p className="text-muted-foreground">Connect Pinterest, manage boards, and configure secure API credentials.</p></div><Card><CardHeader><CardTitle>Pinterest Account</CardTitle><CardDescription>OAuth tokens are encrypted before storage.</CardDescription></CardHeader><CardContent><Button asChild><Link href="/api/pinterest/oauth/start">Connect Pinterest</Link></Button></CardContent></Card></AppShell>; }
