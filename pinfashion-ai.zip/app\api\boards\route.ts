import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { secureJson } from "@/lib/security";

export async function GET() {
  const user = await requireUser();
  const accounts = await prisma.pinterestAccount.findMany({ where: { userId: user.id }, include: { boards: true } });
  return secureJson({ accounts });
}
