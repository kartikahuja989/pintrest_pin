import { AppShell } from "@/components/app-shell";
import { PinComposer } from "@/components/pin-composer";
export default function CreatePinPage() { return <AppShell><div className="mb-6"><h1 className="text-3xl font-black">Create Pin</h1><p className="text-muted-foreground">Scrape a product, generate SEO assets, then create faceless image variations.</p></div><PinComposer /></AppShell>; }
