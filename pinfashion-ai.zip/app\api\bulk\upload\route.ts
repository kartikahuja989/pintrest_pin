import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth";
import { secureJson } from "@/lib/security";
import { bulkSchema } from "@/lib/validators";
import { bulkQueue } from "@/lib/queue";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const { rows } = bulkSchema.parse(await req.json());
    const job = await bulkQueue.add("generate", { userId: user.id, rows }, { attempts: 2, backoff: { type: "exponential", delay: 60000 } });
    return secureJson({ jobId: job.id, queued: rows.length });
  } catch (error) {
    return secureJson({ error: error instanceof Error ? error.message : "Bulk upload failed" }, { status: 400 });
  }
}
