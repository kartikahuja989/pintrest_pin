import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { secureJson } from "@/lib/security";
import { scheduleSchema } from "@/lib/validators";
import { pinQueue } from "@/lib/queue";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = scheduleSchema.parse(await req.json());
    const scheduledFor = new Date(body.scheduledFor);
    const post = await prisma.scheduledPost.create({ data: { userId: user.id, generatedPinId: body.pinId, pinterestAccountId: body.pinterestAccountId, boardId: body.boardId, scheduledFor } });
    const job = await pinQueue.add("publish", { scheduledPostId: post.id }, { delay: Math.max(0, scheduledFor.getTime() - Date.now()), attempts: 3, backoff: { type: "exponential", delay: 30000 } });
    await prisma.scheduledPost.update({ where: { id: post.id }, data: { jobId: job.id } });
    await prisma.generatedPin.update({ where: { id: body.pinId }, data: { status: "SCHEDULED", scheduledFor } });
    return secureJson({ scheduledPost: post, jobId: job.id });
  } catch (error) {
    return secureJson({ error: error instanceof Error ? error.message : "Schedule failed" }, { status: 400 });
  }
}
