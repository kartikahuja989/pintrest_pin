import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth";
import { secureJson } from "@/lib/security";
import { publishSchema } from "@/lib/validators";
import { prisma } from "@/lib/prisma";
import { publishPin } from "@/services/pinterest";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = publishSchema.parse(await req.json());
    await prisma.generatedPin.findFirstOrThrow({ where: { id: body.pinId, userId: user.id } });
    const created = await publishPin(body.pinId, body.pinterestAccountId, body.boardId);
    return secureJson({ pin: created });
  } catch (error) {
    return secureJson({ error: error instanceof Error ? error.message : "Publish failed" }, { status: 400 });
  }
}
