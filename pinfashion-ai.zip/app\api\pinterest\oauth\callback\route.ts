import { NextRequest, NextResponse } from "next/server";
import { exchangePinterestCode, syncBoards } from "@/services/pinterest";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const userId = req.nextUrl.searchParams.get("state");
  if (!code || !userId) return NextResponse.redirect(new URL("/settings?error=pinterest", req.url));
  const account = await exchangePinterestCode(code, userId);
  await syncBoards(account.id);
  return NextResponse.redirect(new URL("/settings?connected=pinterest", req.url));
}
