import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { pinterestAuthUrl } from "@/services/pinterest";

export async function GET() {
  const user = await requireUser();
  redirect(pinterestAuthUrl(user.id));
}
