import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";
import { secureJson } from "@/lib/security";
import { contentSchema } from "@/lib/validators";
import { generatePinterestContent } from "@/services/ai-content";
import type { ScrapedProduct } from "@/types";

export async function POST(req: NextRequest) {
  const limited = rateLimit(req, "content");
  if (limited) return limited;
  try {
    const user = await requireUser();
    const { productId, variations } = contentSchema.parse(await req.json());
    const product = await prisma.product.findFirstOrThrow({ where: { id: productId, userId: user.id } });
    const content = await generatePinterestContent(product as unknown as ScrapedProduct, variations);
    const pins = await Promise.all(content.titles.map((title, index) => prisma.generatedPin.create({
      data: {
        userId: user.id,
        productId: product.id,
        title,
        description: content.descriptions[index % content.descriptions.length],
        tags: [...content.tags, ...content.hashtags],
        boardSuggestion: content.boards[index % content.boards.length],
        layout: content.layouts[index % content.layouts.length],
        destinationUrl: product.affiliateUrl ?? product.sourceUrl,
        status: "GENERATED"
      }
    })));
    await prisma.apiUsage.create({ data: { userId: user.id, route: "/api/generate/content", units: variations } });
    return secureJson({ content, pins });
  } catch (error) {
    return secureJson({ error: error instanceof Error ? error.message : "Generation failed" }, { status: 400 });
  }
}
