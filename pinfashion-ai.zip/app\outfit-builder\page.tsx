import { AppShell } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shirt, Watch, Footprints, Gem } from "lucide-react";
const blocks = [["Matching Pants", Shirt], ["Shoes", Footprints], ["Accessories", Gem], ["Watches", Watch]] as const;
export default function OutfitBuilderPage() { return <AppShell><div className="mb-6"><h1 className="text-3xl font-black">Outfit Builder</h1><p className="text-muted-foreground">AI recommendations for pants, shoes, accessories, watches, and full aesthetics.</p></div><div className="grid gap-4 md:grid-cols-4">{blocks.map(([label, Icon]) => <Card key={label}><CardHeader><Icon className="h-5 w-5 text-primary" /><CardTitle>{label}</CardTitle></CardHeader><CardContent><p className="text-sm text-muted-foreground">Generated from the selected product and Pinterest keyword demand.</p></CardContent></Card>)}</div></AppShell>; }
