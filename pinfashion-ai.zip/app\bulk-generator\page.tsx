import { AppShell } from "@/components/app-shell";
import { BulkUploader } from "@/components/bulk-uploader";
export default function BulkPage() { return <AppShell><div className="mb-6"><h1 className="text-3xl font-black">Bulk Generator</h1><p className="text-muted-foreground">CSV-powered generation for 30+ affiliate pins.</p></div><BulkUploader /></AppShell>; }
