import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { secureJson } from "@/lib/security";
import { buildOutfit } from "@/services/outfit";
import type { ScrapedProduct } from "@/types";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const { productId } = await req.json() as { productId: string };
    const product = await prisma.product.findFirstOrThrow({ where: { id: productId, userId: user.id } });
    const recommendation = await buildOutfit(product as unknown as ScrapedProduct);
    const saved = await prisma.outfitRecommendation.create({ data: { userId: user.id, productId, ...recommendation } });
    return secureJson({ recommendation: saved });
  } catch (error) {
    return secureJson({ error: error instanceof Error ? error.message : "Outfit build failed" }, { status: 400 });
  }
}
