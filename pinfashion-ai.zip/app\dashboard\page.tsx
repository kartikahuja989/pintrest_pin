import { AppShell } from "@/components/app-shell";
import { MetricCard } from "@/components/metric-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AnimatedPanel } from "@/components/animated-panel";
import Link from "next/link";

export default function DashboardPage() {
  return <AppShell><div className="space-y-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><h1 className="text-3xl font-black">Dashboard</h1><p className="text-muted-foreground">Create, schedule, and optimize Pinterest fashion pins.</p></div><Button asChild><Link href="/create-pin">Create New Pin</Link></Button></div><div className="grid gap-4 md:grid-cols-4"><MetricCard title="Generated Pins" value={128} /><MetricCard title="Scheduled" value={36} /><MetricCard title="Impressions" value={84200} /><MetricCard title="CTR" value={7} /></div><AnimatedPanel><Card className="glass"><CardHeader><CardTitle>Today&apos;s Automation Plan</CardTitle></CardHeader><CardContent className="grid gap-3 md:grid-cols-3"><div className="rounded-md bg-muted p-4"><b>Scrape</b><p className="text-sm text-muted-foreground">Import 10 products from affiliate URLs.</p></div><div className="rounded-md bg-muted p-4"><b>Generate</b><p className="text-sm text-muted-foreground">Create faceless 1000x1500 image variants.</p></div><div className="rounded-md bg-muted p-4"><b>Publish</b><p className="text-sm text-muted-foreground">Schedule top pins to matching Pinterest boards.</p></div></CardContent></Card></AnimatedPanel></div></AppShell>;
}
