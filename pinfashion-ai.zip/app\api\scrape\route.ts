import { NextRequest } from "next/server";
import { Prisma, ProductSource as DbProductSource } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";
import { secureJson } from "@/lib/security";
import { scrapeSchema } from "@/lib/validators";
import { scrapeProduct } from "@/services/scraper";

export async function POST(req: NextRequest) {
  const limited = rateLimit(req, "scrape");
  if (limited) return limited;
  try {
    const user = await requireUser();
    const body = scrapeSchema.parse(await req.json());
    const product = await scrapeProduct(body.url, body.affiliateUrl);
    const saved = await prisma.product.create({ data: {
      userId: user.id,
      source: product.source as DbProductSource,
      sourceUrl: product.sourceUrl,
      affiliateUrl: product.affiliateUrl,
      title: product.title,
      brand: product.brand,
      price: product.price,
      currency: product.currency,
      category: product.category,
      gender: product.gender,
      fashionStyle: product.fashionStyle,
      imageUrls: product.imageUrls as Prisma.InputJsonValue,
      metadata: product.metadata as Prisma.InputJsonValue | undefined
    } });
    await prisma.apiUsage.create({ data: { userId: user.id, route: "/api/scrape", units: 1 } });
    return secureJson({ product: saved });
  } catch (error) {
    return secureJson({ error: error instanceof Error ? error.message : "Scrape failed" }, { status: 400 });
  }
}
