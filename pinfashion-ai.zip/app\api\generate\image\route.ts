import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";
import { secureJson } from "@/lib/security";
import { imageSchema } from "@/lib/validators";
import { generatePinterestImages } from "@/services/image-generation";
import type { ScrapedProduct } from "@/types";

export async function POST(req: NextRequest) {
  const limited = rateLimit(req, "image");
  if (limited) return limited;
  try {
    const user = await requireUser();
    const { pinId, variations, layout } = imageSchema.parse(await req.json());
    const pin = await prisma.generatedPin.findFirstOrThrow({ where: { id: pinId, userId: user.id }, include: { product: true } });
    if (!pin.product) throw new Error("Pin is missing product context");
    const images = await generatePinterestImages(pin.product as unknown as ScrapedProduct, variations, layout);
    const saved = await Promise.all(images.map((image) => prisma.generatedImage.create({ data: { generatedPinId: pin.id, prompt: image.prompt, cloudinaryUrl: image.cloudinaryUrl, publicId: image.publicId, layout: image.layout } })));
    await prisma.apiUsage.create({ data: { userId: user.id, route: "/api/generate/image", units: variations } });
    return secureJson({ images: saved });
  } catch (error) {
    return secureJson({ error: error instanceof Error ? error.message : "Image generation failed" }, { status: 400 });
  }
}
