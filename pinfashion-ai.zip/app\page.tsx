import Link from "next/link";
import { ArrowRight, Images, Sparkles, Wand2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  return <main className="min-h-screen bg-[linear-gradient(135deg,#fff7f8,#effaf7_45%,#fff5dd)] dark:bg-[linear-gradient(135deg,#120d13,#10211f_50%,#19150c)]">
    <section className="container grid min-h-screen items-center gap-10 py-12 lg:grid-cols-[1fr_460px]">
      <div className="space-y-8">
        <div className="inline-flex items-center gap-2 rounded-md border bg-background/70 px-3 py-2 text-sm font-medium"><Sparkles className="h-4 w-4 text-primary" /> AI Pinterest affiliate engine</div>
        <div className="space-y-5"><h1 className="max-w-4xl text-5xl font-black leading-tight tracking-normal md:text-7xl">PinFashion AI</h1><p className="max-w-2xl text-lg text-muted-foreground">Paste an Amazon, Flipkart, Myntra, or EarnKaro link and generate faceless Pinterest images, SEO copy, outfit combinations, schedules, and analytics from one workspace.</p></div>
        <div className="flex flex-wrap gap-3"><Button asChild size="lg"><Link href="/dashboard">Open Dashboard <ArrowRight className="h-4 w-4" /></Link></Button><Button asChild variant="outline" size="lg"><Link href="/create-pin">Create Pin</Link></Button></div>
      </div>
      <div className="grid aspect-[2/3] overflow-hidden rounded-lg border bg-card shadow-glow">
        <div className="grid grid-cols-2 gap-3 p-5">
          {["Old Money Essentials", "Sneaker Rotation", "Hidden Face Fit", "Luxury Flat Lay"].map((item, i) => <div key={item} className="relative overflow-hidden rounded-md bg-muted p-4"><div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-primary/25 to-transparent" /><Images className="mb-16 h-8 w-8 text-primary" /><p className="relative text-sm font-bold">{item}</p><p className="relative text-xs text-muted-foreground">1000 x 1500</p></div>)}
        </div>
      </div>
    </section>
  </main>;
}
